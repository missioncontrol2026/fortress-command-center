// Polls Fortress MC scraper for pending jobs, executes in real Chrome tabs.
// Uses chrome.alarms to survive MV3 service-worker suspension.

const API_BASE = 'https://fortress-cre-scraper.onrender.com';
const API_KEY = '1bff8d7e6443e24240dc3703854be74fdb91725a165910816b71500e0c2840ae';

async function poll() {
  try {
    const r = await fetch(`${API_BASE}/queue/pull`, {
      headers: { 'Authorization': `Bearer ${API_KEY}` },
    });
    if (!r.ok) return;
    const job = await r.json();
    if (!job || !job.id) return;

    console.log('[fortress-bridge] got job', job);
    let result;
    try {
      result = await executeJob(job);
      if (typeof result === 'string') { try { result = JSON.parse(result); } catch {} }
    } catch (err) {
      result = { error: err.message };
    }
    await fetch(`${API_BASE}/queue/deliver`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${API_KEY}` },
      body: JSON.stringify({ id: job.id, result }),
    });
    console.log('[fortress-bridge] delivered', job.id);
  } catch (err) {
    console.error('[fortress-bridge] poll error:', err);
  }
}

async function executeJob(job) {
  if (job.vendor === 'reonomy') return runReonomy(job);
  if (job.vendor === 'costar') return runCoStar(job);
  throw new Error(`unknown vendor: ${job.vendor}`);
}

async function runReonomy(job) {
  const [tab] = await chrome.tabs.query({ url: 'https://app.reonomy.com/*' });
  if (!tab) throw new Error('No open Reonomy tab. Please open app.reonomy.com in a tab.');
  // Step 1: extract JWT from page localStorage via MAIN world (returns string)
  const [{ result: token }] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: 'MAIN',
    func: () => {
      const key = '@@auth0spajs@@::UTqjIZf5jqE0RoRCJPD216aT9CWZrq2C::https://app.reonomy.com/v2/::openid profile email';
      const parsed = JSON.parse(localStorage.getItem(key) || '{}');
      return parsed.body?.access_token || '';
    },
  });
  if (!token) return JSON.stringify({ error: 'no reonomy JWT found - please log in to Reonomy in that tab' });

  // Step 2: fetch from background script (host_permissions bypass CORS)
  const params = job.params || {};
  const limit = params.limit || 20;
  const url = 'https://api.reonomy.com/v2/property-list?limit=' + limit;
  const r = await fetch(url, {
    method: 'GET',
    headers: {
      'Authorization': 'Bearer ' + token,
      'Origin': 'https://app.reonomy.com',
      'Referer': 'https://app.reonomy.com/',
    },
  });
  const text = await r.text();
  return JSON.stringify({ status: r.status, body: text.slice(0, 20000) });
}

async function runCoStar(job) {
  const [tab] = await chrome.tabs.query({ url: 'https://product.costar.com/*' });
  if (!tab) throw new Error('No open CoStar tab. Please open product.costar.com in a tab.');
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: 'MAIN',
    func: async (jobParams) => {
      const query = `query CompaniesSearch($searchRequest: CompaniesSearchRequestInput!) { companies { companiesSearchWithList(searchRequest: $searchRequest) { data { id companyKey locationName hierarchy ownerType cityId stateId countryCode countryId numberOfProperties buildingSqFtTotal averageSqFtTotal primaryPropertyType acquistitions dispositions forSalePriceTotal numberOfForSales continentalFocus territory } } } }`;
      const variables = {
        searchRequest: {
          pageNumber: 1,
          pageSize: Math.min(Math.max((jobParams.limit || 20) * 2, 20), 100),
          searchCriteria: {
            portfolio: {
              buildingAreaSqFtTotal: { minimum: jobParams.min_portfolio_sf || 100000 },
              numberOfPropertiesTotal: { minimum: 25 },
            },
            sortType: 0,
          },
        },
      };
      const r = await fetch('/suiteapps/owners/graphql', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, variables, operationName: 'CompaniesSearch' }),
      });
      const text = await r.text();
      return JSON.stringify({ status: r.status, body: text.slice(0, 100000) });
    },
    args: [job.params || {}],
  });
  return result;
}

// Use chrome.alarms to schedule polling (survives service worker suspension)
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('poll', { periodInMinutes: 0.1 }); // 6s (minimum)
  poll();
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create('poll', { periodInMinutes: 0.1 });
  poll();
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'poll') poll();
});

// Ensure alarm exists on every load (in case service worker restarts)
chrome.alarms.get('poll', (a) => {
  if (!a) chrome.alarms.create('poll', { periodInMinutes: 0.1 });
});
poll();
